package com.currencyconverter;

import com.currencyconverter.gui.MainFrame;

public class Main {
    public static void main(String[] args) {
        new MainFrame();   // launch GUI
    }
}
